// Komponentti henkilön nimeä varten (tehtävät 2.6 ja 2.7)

const Name = ({ person }) => {
    return (
      <div>{person.name} </div>
    )
  }
  
  export default Name