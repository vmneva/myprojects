/*
Komponentti henkilön ja numeron lisäämislomaketta varten. Toteutettu propsien avulla pääkomponentista App.
Komponentissa toteutettu metodi addPerson henkilön lisäämistä varten.
HUOM! Käytössä tehtävästä 2.10 alkaen
*/

import axios from 'axios'

const PersonForm = (props) => {

  const addPerson = (event) => {
    event.preventDefault()
    const personObject = {
      name: props.newName,
      number: props.newNumber,
      favourite: Math.random() > 0.5
    }
    if (props.persons.find(({ name }) => name === props.newName)) {
      window.alert(`${props.newName} is already added to phonebook`);
    }
    // Luetteloon lisättävät henkilöt synkronoidaan myös palvelimelle:
    else {
      axios
      .post('http://localhost:3001/api/persons', personObject)
      .then(response => {
        props.setPersons(props.persons.concat(response.data))
        props.setNewName('')
        props.setNewNumber('')
        })
      // Toteutetaan ilmoitus:
      .then(props.setInfoMessage(`${personObject.name} added`))
      .then(setTimeout(() => {
          props.setInfoMessage(null)
          }, 5000)
      )
    }
  }

  return (
    <form onSubmit={addPerson}>
      <div>
        name: <input
        value = {props.newName}
        onChange = {props.handleNameAdd} />
      </div>
      <div>
        number: <input
        value = {props.newNumber}
        onChange = {props.handleNumberAdd} />
      </div>
      <div>
        <button type="submit">add</button>
      </div>
    </form>
    )
  }
  
  export default PersonForm