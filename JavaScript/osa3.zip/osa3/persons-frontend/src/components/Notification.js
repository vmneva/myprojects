// Komponentti ilmoitukselle, luokaksi määritelty info (tehtävä 2.16)

const Notification = ({ message }) => {
  // Jos viesti on tyhjä niin palautetaan null
    if (message === null) {
      return null
    }
  
    return (
      <div className="info">
        {message}
      </div>
    )
  }
  export default Notification