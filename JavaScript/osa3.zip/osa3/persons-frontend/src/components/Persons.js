/*
Komponentti kaikkien henkilöiden renderöimistä varten. Käyttää yhden henkilön renderöivää komponenttia Person.
HUOM! toggleFavourite ja toggleDelete relevantteja vasta tehtävistä 2.13 ja 2.14 alkaen.
*/

import Person from './Person'

const Persons = ({ persons, toggleFavourite, toggleDelete }) => {
    return (
      <div>
        {persons.map(person => 
        <Person 
          key={person.name} 
          number={person.number} 
          person={person}
          toggleFavourite={() => toggleFavourite(person.id)}
          toggleDelete={() => toggleDelete(person.id)} />
        )}
      </div>
    )
  }
  
  export default Persons