/*
Komponentti yksittäisen henkilön renderöimiseen.
HUOM! Buttonit alkavat toimia vasta tehtävistä 2.13 ja 2.14 alkaen
*/

const Person = ({person, toggleFavourite, toggleDelete}) => {
    const label = person.favourite
    ? 'remove from favourites' : 'add to favourites'

    return (
      <div>
        {person.name} {person.number} 
        <button onClick={toggleFavourite}>{label}</button>
        <button onClick={toggleDelete}>delete</button>
    </div>
    )
  }
  
  export default Person