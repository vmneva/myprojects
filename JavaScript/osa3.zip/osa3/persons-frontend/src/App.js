import { useState, useEffect } from 'react'
import axios from 'axios'
import './index.css'
import Persons from './components/Persons'
import PersonForm from './components/PersonForm'
import Notification from './components/Notification'
import personService from './services/persons'

const App = () => {
  const [persons, setPersons] = useState([
    { name: 'Arto Hellas', number: '040-1231244' }
  ]) 
  const [newName, setNewName] = useState('')
  const [newNumber, setNewNumber] = useState('')
  const [infoMessage, setInfoMessage] = useState(null)

  const hook = () => {
    axios
      .get('http://localhost:3001/api/persons')
      .then(response => {
        setPersons(response.data)
      })
  }
  useEffect(hook, [])
  
  const toggleFavourite = id => {
    const person = persons.find(p => p.id === id)
    const changedPerson = { ...person, favourite: !person.favourite }

    personService
      .update(id, changedPerson)
      .then(returnedPerson => {
        setPersons(persons.map(person => person.id !== id ? person : returnedPerson))
      })
      // Toteutetaan ilmoitus:
      .then(setInfoMessage(`Favourite status of ${changedPerson.name} changed`))    
      .then(setTimeout(() => {
          setInfoMessage(null)
        }, 2000)
      )
}
  const toggleDelete = id => {
    const deletedPerson = persons.find(p => p.id === id)

    if (window.confirm(`Delete ${deletedPerson.name} ?`)) {
      personService
        .poista(deletedPerson.id)
        .then(setPersons(persons.filter((deletedPerson) => deletedPerson.id !== id)))  
        // Toteutetaan ilmoitus:
        .then(setInfoMessage(`${deletedPerson.name} deleted`))
        .then(setTimeout(() => {
            setInfoMessage(null)
            }, 3000)
          )
    }
  }
  
  const handleNameAdd = (event) => {
    setNewName(event.target.value)
      
  }
  const handleNumberAdd = (event) => {
    setNewNumber(event.target.value)
  }
  return (
    <div>
      <h2>Phonebook</h2>
      <Notification message={infoMessage} />

      <h3>Add a new</h3>
      <PersonForm persons = {persons} newName = {newName} newNumber = {newNumber} 
      handleNameAdd = {handleNameAdd} handleNumberAdd = {handleNumberAdd} 
      setPersons = {setPersons} setNewName = {setNewName} setNewNumber = {setNewNumber} 
      infoMessage = {infoMessage} setInfoMessage = {setInfoMessage} />

      <h2>Numbers</h2>
          <Persons persons = {persons} toggleFavourite = {toggleFavourite} toggleDelete = {toggleDelete} />
    </div>
  )

}

export default App

